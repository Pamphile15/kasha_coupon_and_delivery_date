<link rel="stylesheet" type="text/css" href="<?php echo $url ?>list.css">
<style type="text/css">
	.custom-header{
  	 width: 50%;
	/*border-right: 2px dashed #222;*/

	}

	.separator{ 
	 width:100%;
	 border-bottom: 2px dashed #222;
	 border-height:10px;

	}
	.simple-end{
		width: 50%;
		border-right:2px solid black;
	}
	.sep{
		border:2px solid black;
		width: 20px;
	}
</style>
<div class="page">


	<?php
	$pg_num = 0;
	foreach ( $orders as $order ) {
		$pg_num++;
		$order_number = ltrim( $order->get_order_number(), '#' );
		$billing_phone = $order->billing_phone;
		$first_name = $order->billing_first_name;
		$last_name = $order->billing_last_name;
		$company = $order->billing_company;
		$address1 = $order->billing_address_1;
		$address2 = $order->billing_address_2;
		$city =	$order->billing_city;
		?>
		<div>

<!--KASHA CUSTOMIZATIONS--> 
<div class='simple-end'><br> </div> 
<!-- simple end -->


    <div class="custom-header">            
		<table widht="100%">
		  <tr>
		    <td align="left" valign="top">
			    <b>
			    	<?php 	echo $first_name; echo $last_name;?><br>
			    	Phone:&nbsp 	<?php 	echo $billing_phone; ?><br>
			    </b>
			    <?php 	echo $company;?><br>
			    <?php 	echo $address1;?><br>
			    <?php 	echo $address2;?><br>
			    <?php 	echo $city;?><br>

		    </td>
		    <td align="right" valign="top">
		    	<div>
					<b>Order Amount: <?php echo $order->get_formatted_order_total(); ?></b><br>
				</div>
		    	<div class="barcode">
					<div><?php echo __( 'Invoice', 'woocommerce-pickingpal' ) ?> #<?php echo $order_number; ?></div>
					<font face="IDAutomationHC39M">(<?php echo $order_number; ?>)</font>
				</div>
		    </td>
		  </tr>
		   <tr>
		    <td colspan="2" valign="top">
				<p class="thankyou-message">Murakoze guhahira muri Kasha! Thank you! Ugize ikibazo hamagara 9111 (Questions? Call 9111).
				</p>
		    </td>
		  </tr>
		</table>
	</div>
<div>
</div>  
<div class='sep'>  </div>
<!-- simple horizontal end -->

<!-- END OF LAMBERT CUSTOMIZATION -->
<?php

		$img = get_option( 'pickingpal-logo' );
		if ( $img ) {
			?>
				<img src="<?php echo $img ?>" class="logo">
				<?php
			}
			?>
		</div>
		<div class="info">
	<?php echo nl2br( get_option( 'pickingpal-contact' ) ); ?>
		</div>
		<div class="clearfix"></div>
		<div class="border-x"></div>
		<div class="info1">
			<table>
				<tr>
					<td>
						<h3><?php echo __( 'Billing Address', 'woocommerce-pickingpal' ) ?></h3>
						<div class="info2">
	<?php echo $order->get_formatted_billing_address(); ?>
						</div>
					</td>
					<td><!--KASHA CUSTOMIZATION
						<h3><?php echo __( 'Shipping Address', 'woocommerce-pickingpal' ) ?></h3>
						<div class="info2">
	<?php echo $order->get_formatted_shipping_address(); ?>-->
						</div>
					</td>
					<td>
						<h3><?php echo __( 'Shipping method', 'woocommerce-pickingpal' ) ?></h3>
						<div class="info2">
	<?php echo $order->get_shipping_method(); ?>
						</div>
					</td>
					<td>
						<h3><?php echo __( 'Total amount', 'woocommerce-pickingpal' ) ?></h3>
						<div>
	<?php echo $order->get_formatted_order_total(); ?>
						</div>
						<div>
	<?php echo $order->post_date; ?>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<div class="barcode">
			<div><?php echo __( 'Invoice', 'woocommerce-pickingpal' ) ?> #<?php echo $order_number; ?></div>
			<font face="IDAutomationHC39M">(<?php echo $order_number; ?>)</font>
		</div>
        <h3 style="clear: both;"><?php
            echo __('Order Date: ', 'woocommerce-pickingpal');
            echo date('m-d-Y',strtotime($order->order_date));
            ?></h3>

            <h3 style="clear: both;">
            <?php
              

        global $wpdb;

        	$datestring = get_post_meta( $order_number, '_wc_acof_14', true );

        	echo __('Delivery date: ', 'woocommerce-pickingpal');
            
            ?>	
          <tr>
                  <?php echo date('m-d-Y',$datestring); ?>
            </tr>
         
            </h3> 

            <h3 style="clear: both;">
            <?php
              
        $tabledata= "$wpdb->prefix"."woocommerce_order_items";
        $result = $wpdb->get_results( "SELECT * FROM $tabledata WHERE order_id='$order_number' AND order_item_type='coupon'");


        $resultcount=$wpdb->get_results("SELECT COUNT(*) FROM wolla_woocommerce_order_items WHERE order_id='$order_number' AND order_item_type='coupon'");
       
        foreach ( $result as $print )  
        if ($resultcount=1) {
         	
         
        $appliedcoupon=$print->order_item_name;
        echo __('Applied coupon: ', 'woocommerce-pickingpal');
            
            ?>	
          <tr>
                  <?php echo $appliedcoupon;
                  } 

         ?>
                 
                            </tr>
         
            </h3>

		<table class="products-list">
			<tr class="item-line">
				<th class="header-list"><?php echo __( 'Order Item', 'woocommerce-pickingpal' ) ?></th>
				<th class="header-list"><?php echo __( 'Price', 'woocommerce-pickingpal' ) ?></th>
				<th class="header-list"><?php echo __( 'Quantity', 'woocommerce-pickingpal' ) ?></th>
				<th class="header-list"><?php echo __( 'Subtotal', 'woocommerce-pickingpal' ) ?></th>
			</tr>
	<?php
	foreach ( $order->get_items() as $item ) {


		$_product = $order->get_product_from_item( $item );

		$sku		 = $variation	 = '';

		if ( $_product )
			$sku			 = $_product->get_sku();
		$item_meta		 = new WC_Order_Item_Meta( $item[ 'item_meta' ] );
		$variation_data	 = $item_meta->get_formatted();
		if ( $_product && !empty( $variation_data ) ) {
			$variation = array();
			foreach ( $variation_data as $var ) {
				$variation[] = $var[ 'label' ] . ': ' . $var[ 'value' ];
			}
			$variation	 = implode( ' | ', $variation );
			$variation	 = str_replace( 'attribute_', '', $variation );
		}

		if ( $order->display_cart_ex_tax || !$order->prices_include_tax ) {
			$ex_tax_label	 = ( $order->prices_include_tax ) ? 1 : 0;
			$price			 = wc_price( $order->get_line_subtotal( $item ), array( 'ex_tax_label' => $ex_tax_label ) );
		} else {
			$price = wc_price( $order->get_line_subtotal( $item, TRUE ) );
		}
		?>
				<tr class="item-line">
					<td>
						<div><?php echo apply_filters( 'woocommerce_order_product_title', $item[ 'name' ], $_product ) ?></div>
						<div><?php echo $variation ?></div>
						<div>SKU: <?php echo $sku ?></div>
					</td>
					<td>
		<?php echo $_product->get_price(); ?>
					</td>
					<td><?php echo $item[ 'qty' ] ?></td>
					<td><?php echo $price ?></td>
				</tr>
		<?php
	}
	?>
			<tr class="total-x">
				<td></td>
				<td></td>
				<td class="item-line"><?php echo __( 'Subtotal', 'woocommerce-pickingpal' ) ?>:</td>
				<td class="item-line">
	<?php echo $order->get_formatted_order_total(); ?>
				</td>
			</tr>
			<tr class="total-x">
				<td></td>
				<td></td>
				<td class="item-line"><?php echo __( 'Shipping', 'woocommerce-pickingpal' ) ?>:</td>
				<td class="item-line"><?php echo $order->get_shipping_to_display(); ?></td>
			</tr>
			<tr class="total-x">
				<td></td>
				<td></td>
				<td class="item-line"><?php echo __( 'Discount', 'woocommerce-pickingpal' ) ?>:</td>
				<td class="item-line">
	<?php echo wc_price( $order->order_discount ); ?>
				</td>
			</tr>
			<tr class="total">
				<td></td>
				<td></td>
				<td>Total:</td>
				<td>
	<?php echo wc_price( $order->order_total ); ?> 
				</td>
			</tr>
		</table>
		<?php if($pg_num < count($orders) ) { ?>
		<p class="pagebreak"></p> 
		<?php } ?>
	<?php
}
?>
</div>
<script>
	window.print()
</script>
