<?php
if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="wp-table"></div>
<div id="modal" style="display: none;">
    <div id="modal_body" ></div>       
</div>
<?php add_thickbox(); ?>
<script>


	var ajaxurl = '<?php echo $ajaxurl ?>';

	jQuery( document ).ready( function( $ ) {
		var loader = $( '#loader' ).html()
//        var m = myModal("modal");
		var action = 'wp_log_table'

		$.get( ajaxurl, 'action=wc_pickingpal&p_act=' + action, function( data ) {
			$( '.wp-table' ).html( data )
			add_event()
		}, 'html' )

		function find() {
			var query = $( '#pickingpal' ).serialize();

			$.get( ajaxurl, 'action=wc_pickingpal&p_act=' + action + '&' + query, function( data ) {
				$( '.wp-table' ).html( data )
				add_event();
			}, 'html' )
		}

		function add_event() {
			$( '.wp-list-table' ).find( 'a' ).not( ".modal_open" ).click( function() {
				var query = $( this ).attr( 'href' ).split( '?' )[1];

				$.get( ajaxurl, 'action=wc_pickingpal&p_act=' + action + '&' + query, function( data ) {
					$( '.wp-table' ).html( data )
					add_event()
				}, 'html' )
				return false;
			} )
			$( '#pickingpal' ).find( 'input' ).keypress( function( ev ) {
				if ( ev.charCode == 13 ) {
					find()
					return false;
				}
			} )
			$( '#search-submit' ).click( function() {
				find()
				return false;
			} )

			$( ".modal_open" ).click( function( e ) {
				$( '#modal_body' ).html( loader )
				$.get( ajaxurl, 'action=wc_pickingpal&p_act=load_order_log&order_id=' + $( this ).data( 'id' ), function( data ) {
					$( '#modal_body' ).html( data );
					resizeTB( 600 )
				}, 'html' )
			} );
			$( '.pagination-links a:not(.disabled)' ).click( function( e ) {
				var url = $( this ).attr( 'href' );
				$.get( url, '', function( data ) {
					$( '.wp-table' ).html( data )
					add_event()
				}, 'html' )
				return false;
			} )

			$( '.pagination-links a.disabled' ).click( function( e ) {
				return false;
			} )
		}

	} )


//    function myModal(modal) {
//        var $modal = jQuery("#" + modal + "");
//
//        return {
//            open: function() {
//                $modal.draggable();
//                $modal.fadeIn('fast');
//            },
//            close: function() {
//                $modal.fadeOut('fast');
//            }
//            ,
//            body: function(body) {
//                $modal.find("#modal_body").html(body);
//            }
//        };
//    }
</script>
