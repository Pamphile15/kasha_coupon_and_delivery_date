<link rel="stylesheet" id="woocommerce_admin_menu_styles-css" href="<?php echo $url_plugin ?>/woocommerce-pickingpal-template/list.css" type="text/css" media="all">
<font face="IDAutomationHC39M">(<?php echo $barcode; ?>)</font>



