<?php
if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$active_tab = isset( $_REQUEST[ 'tab' ] ) ? $_REQUEST[ 'tab' ] : 'pickingpal';
?>
<div style="display: none;" id="loader">
	<div style="margin-left: 50%;">
		<img style="margin-left:-20px;" src="<?php echo $url ?>/img/preloader.gif">
	</div>

</div>
<h2 class="nav-tab-wrapper" id="tabs">
    <a class="nav-tab <?php echo $active_tab == 'pickingpal' ? 'nav-tab-active' : '' ?>" href="<?php echo admin_url( 'admin.php?page=PickingPal&tab=pickingpal' ) ?>"><?php _e( 'PickingPal', 'woocommerce-pickingpal' ) ?></a><a class="nav-tab <?php echo $active_tab == 'log' ? 'nav-tab-active' : '' ?>" href="<?php echo admin_url( 'admin.php?page=PickingPal&tab=log' ) ?>"><?php _e( 'Log', 'woocommerce-pickingpal' ) ?></a><a class="nav-tab <?php echo $active_tab == 'settings' ? 'nav-tab-active' : '' ?>" href="<?php echo admin_url( 'admin.php?page=PickingPal&tab=settings' ) ?>"><?php _e( 'Settings', 'woocommerce-pickingpal' ) ?></a><a class="nav-tab <?php echo $active_tab == 'export' ? 'nav-tab-active' : '' ?>" href="<?php echo admin_url( 'admin.php?page=PickingPal&tab=export' ) ?>"><?php _e( 'Export', 'woocommerce-pickingpal' ) ?></a>
</h2>
<div class="tabs-content">
	<?php $WC_PickingPal->render( $active_tab, array( 'logo' => $logo, 'url' => $url, 'ajaxurl' => $ajaxurl, 'WC_PickingPal' => $WC_PickingPal ) ); ?>
</div>

<script>
	var ajax = "<?php echo $ajaxurl ?>"
</script>
