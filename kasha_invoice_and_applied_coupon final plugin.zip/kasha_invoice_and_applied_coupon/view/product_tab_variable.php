<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<?php
foreach ($product->get_available_variations() as $v) {
    if ($v['variation_is_visible'] && $v['variation_is_active']) {
        ?>
        <div class="pickingpal-variant">
            <div class="pickingpal-variant-image" style="margin-right: 20px;width:30%;float:left;"><img src='<?= $v['image_src'] ?>'/></div>
            <div class="pickingpal-variant-desc" style="width:60%;">
                <?php
                foreach ($skus as $key => $value) {

                    if (($value['enabled'] == 'off') || ($value['product_page'] == 'off'))
                        continue;
                    $sku = get_post_meta($v['variation_id'], $key);
                    if (empty($sku[0])){
                     echo '<p><strong>This variation not have skus</strong></p>';    
                        continue;
                    }
                    echo '<p><strong>' . $value['label'] . ':</strong>' . $sku[0] . '</p>';
                }
                ?>                            
            </div>
            <div style='clear:both'></div></div><hr>
        <?php
    }
}