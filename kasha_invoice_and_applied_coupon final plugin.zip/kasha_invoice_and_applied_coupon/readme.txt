disable woocommerce pickingpal plugin before installing this plugin
